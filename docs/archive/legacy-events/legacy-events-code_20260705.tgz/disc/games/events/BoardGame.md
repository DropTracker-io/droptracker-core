





# DropTracker Event System Documentation

## Overview

The DropTracker Event System allows server administrators to create and manage board game events for their community. Players can join teams, roll dice, complete tasks, and earn points as they progress through the game board.

## Command Reference

### Event Management Commands

| Command | Description | Usage | Permissions |
|---------|-------------|-------|------------|
| `/event create` | Create a new event | `/event create name:"Spring Tournament" description:"A fun board game event" start_date:"2025-04-01"` | Admin |
| `/event list` | List all events that you have access to. | `/event list` | Anyone |
| `/event status` | Check an event's current status | `/event status event_id:1` | Anyone |
| `/event cancel` | Cancel an event that is in setup mode | `/event cancel event_id:1` | Admin |

### Team Management Commands

| Command | Description | Usage | Permissions |
|---------|-------------|-------|------------|
| `/event team_create` | Create a new team | `/event team_create event_id:1 name:"Dragon Slayers"` | Admin |
| `/event team_add` | Add a player to a team | `/event team_add event_id:1 team_name:"Dragon Slayers" player:@Username` | Admin |
| `/event team_remove` | Remove a player from a team | `/event team_remove event_id:1 player:@Username` | Admin |
| `/event team_list` | View all teams in an event and their statuses | `/event team_list event_id:1` | Anyone |

### Game Commands

| Command | Description | Usage | Permissions |
|---------|-------------|-------|------------|
| `/event roll` | Roll dice and move your team | `/event roll event_id:1` | Team Member |
| `/event status` | Check your team's status | `/event status event_id:1` | Team Member |
| `/event complete_task` | Check if your team's task is complete | `/event complete_task event_id:1` | Team Member |
| `/event leaderboard` | View the event leaderboard | `/event leaderboard event_id:1` | Anyone |
| `/event shop` | View the event shop | `/event shop event_id:1` | Team Member |
| `/event buy` | Buy an item from the shop | `/event buy event_id:1 item_name:"Health Potion"` | Team Member |
| `/event use` | Use an item from your inventory | `/event use event_id:1 item_name:"Health Potion"` | Team Member |

## Game Flow

1. **Event Creation**: An admin creates a new event using `/event create`
2. **Team Setup**: Teams are created and players are added to teams
3. **Event Start**: The admin starts the event by clicking the "Start Event" button
4. **Gameplay**:
   - Teams roll dice to move on the board
   - Landing on a tile assigns a task
   - Teams complete tasks to earn points and items
   - Teams can buy items from the shop
   - Teams can use items for various effects
5. **Winning**: The first team to reach the specified point threshold wins

## Detailed Command Usage

### Creating an Event

```
/event create name:"Summer Tournament" description:"A board game event for the summer" start_date:"2025-06-01"
```

This creates a new event in "setup" status. The event will appear in the event list but won't be playable until started.

### Starting an Event

After creating an event, use `/event status event_id:1` to view the event details. Click the "Start Event" button to activate the event.

### Creating Teams

```
/event team_create event_id:1 name:"Fire Dragons"
/event team_create event_id:1 name:"Ice Wolves"
```

### Adding Players to Teams

```
/event team_add event_id:1 team_name:"Fire Dragons" player:@Player1
/event team_add event_id:1 team_name:"Ice Wolves" player:@Player2
```

### Rolling Dice

Team members can roll dice to move on the board:

```
/event roll event_id:1
```

The system will automatically determine which team the player belongs to. After rolling, the player will move to a new position and may be assigned a task.

### Completing Tasks

When a team lands on a tile, they may be assigned a task that requires collecting specific items. Once the team believes they have completed the task, they can check:

```
/event complete_task event_id:1
```

If the task is complete, the team will receive points and possibly items. They can then roll again to continue.

### Buying Items

Teams can spend gold to buy items from the shop:

```
/event buy event_id:1 item_name:"Health Potion"
```

### Using Items

Teams can use items from their inventory for various effects:

```
/event use event_id:1 item_name:"Health Potion"
```

### Checking Team Status

Team members can check their status at any time:

```
/event status event_id:1
```

This shows the team's position, points, gold, inventory, and current task.

### Viewing the Leaderboard

Anyone can view the current standings:

```
/event leaderboard event_id:1
```

## Admin Commands

### Initializing a Game

If a game is not properly loaded in memory, admins can initialize it:

```
/event status event_id:1
```

Then click the "Initialize Game" button.

### Cancelling an Event

To cancel an active event:

```
/event status event_id:1
```

Then click the "Cancel Event" button.

## Troubleshooting

### Game Not Responding

If the game is not responding to commands, check if it's properly initialized:

1. Use `/event status event_id:1` to check if the game is "Active in Memory"
2. If not, click the "Initialize Game" button

### Player Can't Roll

If a player can't roll, check:

1. Is the player in a team? Use `/event team_list event_id:1` to verify
2. Does the team have an incomplete task? Use `/event status event_id:1` to check
3. Complete the current task before rolling again

### Missing Game State

If you see "Game state not found" errors:

1. The game may not have been properly initialized
2. Use the "Initialize Game" button to create a new game state

## Best Practices

1. **Create teams before starting the event**: Set up all teams and add players before activating the event
2. **Use a dedicated channel**: Create a specific channel for event commands to avoid cluttering other channels
3. **Explain tasks clearly**: Make sure players understand what items they need to collect for each task
4. **Balance team sizes**: Try to keep teams roughly equal in size for fair competition
5. **Regular backups**: The system automatically saves game state, but consider taking manual backups for important events
